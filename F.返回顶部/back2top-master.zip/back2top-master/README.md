网页返回顶部组件（back2top）
==========================

### 简介
基于jQuery的返回顶部控件，使用方法简单，只需要Back2top.init()即可；如果用户需要自定义样式，可以直接更改back2top.css文件

### 详细api文档
http://www.baidufe.com/component/back2top/index.html